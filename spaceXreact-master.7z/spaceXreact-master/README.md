## Task

1. Use SpaceX API to get Launchpads for Launches
2. Draw Launchpads on the map as circles
3. When we hover over the launch item in the list, highlight 
the launchpad related to this launch.

Link to D3 Geo docs:
https://github.com/d3/d3-geo