import * as d3 from "d3";
import {containerRef} from "./map";
import {g} from "./map";
import {projection} from "./map";

let lchs;
let lpds;


function LaunchList(props) {

    lchs = props.launches
    lpds = props.launchpads

    return (
        <aside className="aside" id="launchesContainer">
            <h3>Launches</h3>
            <div id="listContainer">


            <ul>
                {lchs.map(lch => {
                    return <li onMouseEnter = {MakePointRed} onMouseLeave = {MakePointBlue} key={lch.id}>{lch.name} </li>
                })}
            </ul>
            </div>
        </aside>
    )
}

export {LaunchList}

function MakePointRed(Event){
    let elem = Event.target

    lchs.map(lch=>{
            if(lch.name == elem["innerText"]){
                lpds.map(lpd=>{
                    if(lch.launchpad == lpd.id){
                        let lat = lpd.latitude
                        let long = lpd.longitude
                        let point = projection([long, lat])
                        svg = d3.select(containerRef.current).select("svg")
                        g.append("circle")
                            .attr("cx", point[0])
                            .attr("cy", point[1])
                            .attr("r", 5)
                            .style("fill", "red")
                            .style("stroke", "red")
                }
            })
        }
    })
}

function MakePointBlue(Event){
    let elem = Event.target

    lchs.map(lch=>{
            if(lch.name == elem["innerText"]){
                lpds.map(lpd=>{
                    if(lch.launchpad == lpd.id){
                        let lat = lpd.latitude
                        let long = lpd.longitude
                        let point = projection([long, lat])
                        svg = d3.select(containerRef.current).select("svg")
                        g.append("circle")
                            .attr("cx", point[0])
                            .attr("cy", point[1])
                            .attr("r", 5)
                            .style("fill", "blue")
                            .style("stroke", "blue")
                }
            })
        }
    })
}
